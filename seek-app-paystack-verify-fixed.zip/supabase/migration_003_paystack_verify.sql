-- SEEK migration 003: atomic donation settlement for the paystack-verify
-- fallback function.
--
-- Run this in the Supabase SQL editor for project ref fzgmpwgibwxxyvapappi,
-- after migration.sql and migration_002_atomic_donations.sql. It does not
-- touch existing tables, data, or the webhook URL — it only adds one new
-- function, reusing the increment_request_amount() function added in
-- migration_002.
--
-- Why: paystack-verify (a fallback the frontend can call if the webhook is
-- slow or hasn't landed yet) and paystack-webhook can both, in principle,
-- try to settle the same donation at close to the same time. Marking the
-- donation successful and incrementing requests.amount_raised need to
-- happen as one atomic, locked operation so the amount is never added
-- twice, no matter which path gets there first or if both fire together.
create or replace function public.settle_donation(
  p_donation_id uuid,
  p_paystack_reference text,
  p_paid_at timestamptz default null
)
returns public.donations
language plpgsql
security definer
set search_path = public
as $$
declare
  v_donation public.donations;
begin
  -- Row lock: a concurrent call for the same donation (e.g. the webhook
  -- firing at the same moment) blocks here until this transaction commits,
  -- then sees status = 'successful' and returns early below instead of
  -- crediting the amount a second time.
  select * into v_donation
  from public.donations
  where id = p_donation_id
  for update;

  if not found then
    raise exception 'Donation % not found', p_donation_id;
  end if;

  -- Defense in depth: refuse to settle a donation under the wrong
  -- reference, even though the caller already looked it up by reference.
  if v_donation.paystack_reference is distinct from p_paystack_reference then
    raise exception 'Reference mismatch for donation %', p_donation_id;
  end if;

  -- Idempotent no-op — already settled by the webhook or an earlier call.
  if v_donation.status = 'successful' then
    return v_donation;
  end if;

  if v_donation.status <> 'pending' then
    raise exception 'Donation % is not pending (status: %)', p_donation_id, v_donation.status;
  end if;

  update public.donations
  set status = 'successful',
      paid_at = coalesce(p_paid_at, now())
  where id = p_donation_id
  returning * into v_donation;

  if v_donation.request_id is not null then
    perform public.increment_request_amount(v_donation.request_id, v_donation.amount);
  end if;

  return v_donation;
end;
$$;

-- Callable only by the service role — this settles real money-tracking
-- state and must never be reachable from the browser (anon/authenticated).
revoke all on function public.settle_donation(uuid, text, timestamptz) from public;
grant execute on function public.settle_donation(uuid, text, timestamptz) to service_role;
