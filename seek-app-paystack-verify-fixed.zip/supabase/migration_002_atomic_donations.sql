-- SEEK migration 002: atomic donation-amount increment.
--
-- Run this in the Supabase SQL editor for project ref fzgmpwgibwxxyvapappi,
-- after migration.sql. It does not touch existing data, tables, or the
-- webhook URL — it only adds one new function.
--
-- Why: paystack-webhook previously updated requests.amount_raised by
-- reading the current value, adding the paid amount in JS, then writing
-- the computed literal back (select, then update). Two webhook deliveries
-- for the same request landing close together — which Paystack does retry
-- — could race and silently lose an increment. This function does the
-- whole thing as one atomic UPDATE instead.
create or replace function public.increment_request_amount(p_request_id uuid, p_amount numeric)
returns public.requests
language plpgsql
security definer
set search_path = public
as $$
declare
  v_request public.requests;
begin
  update public.requests
  set amount_raised = amount_raised + p_amount,
      status = case
        when amount_needed > 0 and (amount_raised + p_amount) >= amount_needed
          then 'fulfilled'::public.request_status
        else 'partially_funded'::public.request_status
      end
  where id = p_request_id
  returning * into v_request;

  return v_request;
end;
$$;

-- Only the webhook (service role) should call this — it moves
-- money-tracking state and should never be reachable from the browser.
revoke all on function public.increment_request_amount(uuid, numeric) from public;
grant execute on function public.increment_request_amount(uuid, numeric) to service_role;
