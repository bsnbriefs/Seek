import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

Deno.serve(async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });

  try {
    const raw = await req.text();
    const signature = req.headers.get("x-paystack-signature");
    const secret = Deno.env.get("PAYSTACK_SECRET_KEY");

    if (!secret) return new Response("Server configuration error", { status: 500 });
    if (!signature) return new Response("Missing signature", { status: 401 });

    const key = await crypto.subtle.importKey(
      "raw",
      new TextEncoder().encode(secret),
      { name: "HMAC", hash: "SHA-512" },
      false,
      ["verify"],
    );

    const valid = await crypto.subtle.verify(
      "HMAC",
      key,
      hexToBytes(signature),
      new TextEncoder().encode(raw),
    );

    if (!valid) return new Response("Invalid signature", { status: 401 });

    const event = JSON.parse(raw);
    console.log("PAYSTACK EVENT:", event.event);

    // We only need successful charges. All other valid Paystack events are
    // acknowledged so Paystack does not retry them.
    if (event.event !== "charge.success") return new Response("ok", { status: 200 });

    const reference = event.data?.reference;
    const paidAmount = Number(event.data?.amount || 0) / 100;
    const currency = event.data?.currency;

    console.log("PAYSTACK REFERENCE:", reference);
    console.log("PAYSTACK AMOUNT:", paidAmount);
    console.log("PAYSTACK CURRENCY:", currency);

    if (!reference) return new Response("Missing reference", { status: 400 });

    // This Supabase Edge Function may receive Paystack webhook events for
    // other products that share the same Paystack account/webhook endpoint.
    // Seek transactions always use the SEEK- reference prefix. Ignore all
    // other references with HTTP 200 so unrelated transactions are not
    // retried and are never treated as Seek donations.
    if (!String(reference).startsWith("SEEK-")) {
      console.log("IGNORING NON-SEEK PAYSTACK REFERENCE:", reference);
      return new Response("ok", { status: 200 });
    }

    if (currency !== "NGN") {
      console.error("CURRENCY MISMATCH:", { reference, currency });
      return new Response("Currency mismatch", { status: 400 });
    }

    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    if (!serviceRoleKey || !supabaseUrl) {
      return new Response("Server configuration error", { status: 500 });
    }

    const supabase = createClient(supabaseUrl, serviceRoleKey);

    const { data: donation, error: lookupError } = await supabase
      .from("donations")
      .select("id, request_id, amount, status, paystack_reference")
      .eq("paystack_reference", reference)
      .maybeSingle();

    if (lookupError) {
      console.error("DONATION LOOKUP ERROR:", lookupError);
      return new Response("Database lookup error", { status: 500 });
    }

    if (!donation) {
      // A SEEK-shaped reference that does not belong to a current donation is
      // still acknowledged. Returning 404 would make Paystack repeatedly retry
      // the event without any useful action to take.
      console.error("SEEK DONATION NOT FOUND:", reference);
      return new Response("ok", { status: 200 });
    }

    if (donation.status === "successful") {
      console.log("DONATION ALREADY SUCCESSFUL:", donation.id);
      return new Response("ok", { status: 200 });
    }

    if (Math.abs(paidAmount - Number(donation.amount)) > 0.01) {
      console.error("AMOUNT MISMATCH", {
        expected: donation.amount,
        received: paidAmount,
        reference,
      });
      return new Response("Amount mismatch", { status: 400 });
    }

    // Use the same atomic settlement path as paystack-verify. This prevents
    // webhook + verification races from double-crediting amount_raised.
    const paidAt = event.data?.paid_at || null;
    const { data: settled, error: settleError } = await supabase
      .rpc("settle_donation", {
        p_donation_id: donation.id,
        p_paystack_reference: reference,
        p_paid_at: paidAt,
      })
      .single();

    if (settleError) {
      console.error("SETTLE DONATION ERROR:", settleError);
      return new Response("Failed to settle donation", { status: 500 });
    }

    console.log("DONATION SETTLED BY WEBHOOK:", {
      donationId: settled.id,
      requestId: settled.request_id,
    });

    return new Response("ok", { status: 200 });
  } catch (error) {
    console.error("WEBHOOK ERROR:", error);
    return new Response(error instanceof Error ? error.message : "Webhook error", { status: 500 });
  }
});

function hexToBytes(hex: string) {
  if (!/^[0-9a-fA-F]+$/.test(hex) || hex.length % 2 !== 0) {
    throw new Error("Invalid signature format");
  }

  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < bytes.length; i++) {
    bytes[i] = parseInt(hex.substring(i * 2, i * 2 + 2), 16);
  }
  return bytes;
}
