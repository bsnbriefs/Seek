import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

// Matches the CORS pattern already used by paystack-initialize in this repo.
const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type' };

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { ...cors, 'Content-Type': 'application/json' } });
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return json({ verified: false, error: 'Method not allowed' }, 405);

  try {
    const { reference } = await req.json().catch(() => ({}));

    if (!reference || typeof reference !== 'string') {
      return json({ verified: false, error: 'Missing reference.' }, 400);
    }
    // Only ever verify Seek-issued references — never forward an arbitrary
    // caller-supplied string to Paystack or use it to look up a donation.
    if (!reference.startsWith('SEEK-')) {
      return json({ verified: false, error: 'Unrecognized reference format.' }, 400);
    }

    const secretKey = Deno.env.get('PAYSTACK_SECRET_KEY');
    if (!secretKey) {
      console.error('PAYSTACK_SECRET_KEY not configured');
      return json({ verified: false, error: 'Server configuration error.' }, 500);
    }

    const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);

    // 1. Confirm the reference actually belongs to a donation we created,
    // and check its current state, before calling out to Paystack at all.
    const { data: donation, error: lookupError } = await supabase
      .from('donations')
      .select('id, request_id, amount, status, paystack_reference')
      .eq('paystack_reference', reference)
      .maybeSingle();

    if (lookupError) {
      console.error('DONATION LOOKUP ERROR:', lookupError);
      return json({ verified: false, error: 'Database lookup error.' }, 500);
    }
    if (!donation) {
      console.error('VERIFY: donation not found for reference', reference);
      return json({ verified: false, error: 'Donation not found.' }, 404);
    }

    // Idempotent short-circuit — never re-add the amount, and no need to
    // call Paystack again if the webhook (or an earlier verify call)
    // already settled this donation.
    if (donation.status === 'successful') {
      return json({ verified: true, settled: true, alreadySettled: true, donationId: donation.id });
    }
    if (donation.status !== 'pending') {
      console.error('VERIFY: donation not pending', { id: donation.id, status: donation.status });
      return json({ verified: false, error: `Donation is not pending (status: ${donation.status}).` }, 409);
    }

    // 2. Ask Paystack directly — never trust anything the browser claims
    // about payment success or amount.
    const paystackRes = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, {
      headers: { Authorization: `Bearer ${secretKey}` },
    });
    const result = await paystackRes.json().catch(() => null);

    if (!paystackRes.ok || !result?.status) {
      console.error('PAYSTACK VERIFY REQUEST FAILED:', { reference, httpStatus: paystackRes.status, message: result?.message });
      return json({ verified: false, error: 'Could not reach Paystack for verification.' }, 502);
    }

    const data = result.data;
    if (data?.status !== 'success') {
      console.log('VERIFY: transaction not successful at Paystack', { reference, paystackStatus: data?.status });
      return json({ verified: false, error: 'Payment was not successful.', paystackStatus: data?.status ?? null });
    }

    if (data.currency !== 'NGN') {
      console.error('VERIFY: currency mismatch', { reference, currency: data.currency });
      return json({ verified: false, error: 'Currency mismatch.' }, 400);
    }

    const paidAmountNaira = Number(data.amount || 0) / 100;
    if (Math.abs(paidAmountNaira - Number(donation.amount)) > 0.01) {
      console.error('VERIFY: amount mismatch', { reference, expected: donation.amount, received: paidAmountNaira });
      return json({ verified: false, error: 'Amount mismatch.' }, 400);
    }

    const paidAt = data.paid_at || data.paidAt || null;

    // 3. Settle atomically — marking the donation successful and
    // incrementing the request's amount_raised happen inside one
    // SECURITY DEFINER function (see migration_003_paystack_verify.sql) so
    // this can never double-credit even if the webhook fires at the same
    // moment for the same donation.
    const { data: settled, error: settleError } = await supabase
      .rpc('settle_donation', {
        p_donation_id: donation.id,
        p_paystack_reference: reference,
        p_paid_at: paidAt,
      })
      .single();

    if (settleError) {
      console.error('SETTLE DONATION ERROR:', settleError);
      return json({ verified: false, error: 'Failed to settle donation.' }, 500);
    }

    console.log('VERIFY: donation settled', { donationId: settled.id, requestId: settled.request_id });

    return json({
      verified: true,
      settled: true,
      alreadySettled: false,
      donationId: settled.id,
      requestId: settled.request_id,
    });
  } catch (error) {
    console.error('PAYSTACK VERIFY ERROR:', error);
    return json({ verified: false, error: error instanceof Error ? error.message : 'Unexpected error' }, 500);
  }
});
