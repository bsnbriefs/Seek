# Claude handoff — Seek production readiness

This ZIP is the latest Seek production project available to us, with the Paystack webhook updated to use the configured `SERVICE_ROLE_KEY` server secret and to verify Paystack signatures.

Important: do not expose any secret keys. Review the whole project before changing it. The live Paystack webhook URL is already configured externally as the Supabase `paystack-webhook` function endpoint.

Use the user's production-readiness prompt supplied separately. Preserve working features and inspect the existing architecture first.
