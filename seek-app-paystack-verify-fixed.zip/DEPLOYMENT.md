# Seek production deployment

## 1. Supabase
This project already uses an existing Supabase project (ref `fzgmpwgibwxxyvapappi`) — do not create a new one or recreate tables.

Run, in order, in the SQL Editor:
1. `supabase/migration.sql` (if not already applied — it uses `create table if not exists`, so it's safe to re-run).
2. `supabase/migration_002_atomic_donations.sql` — adds one new function (`increment_request_amount`) used by the webhook fix below. Does not touch existing tables or data.

Add these Vite variables in Vercel (**Project → Settings → Environment Variables**, scope: Production — and Preview too if you preview-deploy):
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_PUBLISHABLE_KEY`

**"Seek backend is not configured yet." on the live site** — the detection code (`src/lib/supabase.js`) is correct and matches these exact variable names; there's no bug in the check itself. This message means the two vars above were empty *in the specific build currently deployed*. In practice that's almost always one of:
- The vars were never added in Vercel at all, or were added only to Preview/Development and not Production.
- The vars were added or edited in Vercel **after** the last deployment. Vite bakes `VITE_*` vars into the JS bundle at build time — it does not read them at runtime — so adding/changing them in the dashboard has no effect until you trigger a new deployment (Deployments → ⋯ → Redeploy, or push a commit).
- A typo in the variable name in Vercel (extra space, wrong case, etc).

After confirming the two variables are set for Production and redeploying, open the browser console on the live site — I added a one-line diagnostic warning that fires only when the check fails, reporting which of the two variables Vite actually saw as present/absent at build time (no values or secrets are logged, just presence booleans), to make this fast to confirm.

## 2. Paystack
Set these Supabase Edge Function secrets:
- `PAYSTACK_SECRET_KEY`

Deploy both functions:
- `paystack-initialize`
- `paystack-webhook`

The production webhook URL is already configured as:
`https://fzgmpwgibwxxyvapappi.supabase.co/functions/v1/paystack-webhook`
— unchanged, do not edit this in the Paystack dashboard.

Never put `PAYSTACK_SECRET_KEY` in Vite or the browser.

## 3. Vercel
Build command: `npm run build`
Output: `dist`
Framework: Vite

## 4. Before public launch
- Create a real admin role and admin RLS policies (there's currently no reviewer/moderation workflow — every published request went through direct RLS inserts with nothing yet to move a request from pending to published besides manual dashboard edits).
- Turn on email/phone authentication and configure redirect URLs.
- Add a private storage bucket for sensitive verification documents and policies restricting access.
- Test successful, failed and abandoned Paystack payments against the fixed webhook, including sending the same event twice to confirm no double-counting.
- Replace all demo impact numbers with live queries.
- Add Terms, Privacy, safeguarding and refund/contact policies.
- Configure a custom domain and production environment variables.

